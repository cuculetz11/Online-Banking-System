package org.poo.command.debug.dto;

public record ErrorPrint(String error, int timestamp) implements AccountDeleteInfo {

}
