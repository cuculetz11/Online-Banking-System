package org.poo.command.debug.dto;

public interface AccountDeleteInfo {

}
